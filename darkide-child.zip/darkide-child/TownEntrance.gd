extends Area2D

@export var target_scene: String = "res://Town1.tscn"
var has_triggered: bool = false
var player = null

func _ready():
	print("TownEntrance: Area2D ready at position: ", global_position)
	print("TownEntrance: Monitoring enabled: ", monitoring)
	print("TownEntrance: Collision Layer: ", collision_layer)
	print("TownEntrance: Collision Mask: ", collision_mask)
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _process(_delta):
	if player and not has_triggered:
		var distance = player.global_position.distance_to(global_position)
		if distance < 150:  # Close enough to trigger
			print("=== TOWNENTRANCE TRIGGERED ===")
			print("TownEntrance: Player is close! Distance: ", distance)
			print("TownEntrance: Loading Town1 scene...")
			print("============================")
			has_triggered = true
			get_tree().call_deferred("change_scene_to_file", target_scene)

func _on_body_entered(body):
	print("TownEntrance: Body entered area - ", body.name)
	player = body

func _on_body_exited(body):
	print("TownEntrance: Body exited area - ", body.name)
	if body == player:
		player = null
