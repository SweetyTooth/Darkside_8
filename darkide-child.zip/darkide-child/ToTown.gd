extends Area2D

@export var target_scene: String = "res://Town1.tscn"

func _ready() -> void:
	print("ToTown: Area2D ready at position: ", global_position)
	print("ToTown: Monitoring enabled: ", monitoring)
	print("ToTown: Monitorable: ", monitorable)
	body_entered.connect(_on_body_entered)
	area_entered.connect(_on_area_entered)

func _on_body_entered(body):
	print("=== COLLISION DETECTED ===")
	print("ToTown: Body entered! Body name: ", body.name)
	print("ToTown: Body position: ", body.global_position)
	print("ToTown: ToTown position: ", global_position)
	print("ToTown: Body type: ", body.get_class())
	print("ToTown: Attempting to change scene to Town1.tscn")
	print("========================")
	get_tree().call_deferred("change_scene_to_file", "res://Town1.tscn")

func _on_area_entered(area):
	print("ToTown: Area entered! Area name: ", area.name)
