extends CharacterBody2D

#Variables
var ram = true
var speed = 400
var dash_speed = 800
var dash_duration = 0.3
var dash_cooldown = 0.3

var is_dashing = false
var can_dash = true
var dash_timer = 0.0
var cooldown_timer = 0.0
var last_direction = Vector2.ZERO

func _movement(_delta: float) -> void:
	var direction = Input.get_vector("left", "right", "up", "down")
	
	# Trigger dash - use just_pressed to avoid spam
	if Input.is_action_just_pressed("Dash") and can_dash and direction != Vector2.ZERO:
		is_dashing = true
		can_dash = false
		dash_timer = dash_duration
		last_direction = direction  # Lock the dash direction
	
	# Store direction for collision detection (but not during dash)
	if direction != Vector2.ZERO and !is_dashing:
		last_direction = direction
	
	# Apply speed based on dash state
	if is_dashing:
		velocity = last_direction * dash_speed  # Use locked direction
		_check_ram_collision()
	else:
		velocity = direction * speed
	
	move_and_slide()
	
	# Handle dash timer
	if is_dashing:
		dash_timer -= _delta
		if dash_timer <= 0:
			is_dashing = false
			cooldown_timer = dash_cooldown  # Start cooldown after dash ends
	
	# Handle cooldown timer
	if !can_dash and !is_dashing:
		cooldown_timer -= _delta
		if cooldown_timer <= 0:
			can_dash = true

func _check_ram_collision():
	# Check if we're hitting any CharacterBody2D while dashing with ram enabled
	for i in get_slide_collision_count():
		var collision = get_slide_collision(i)
		var collider = collision.get_collider()
		
		# If we hit something that has a _push method, push it
		if collider and collider.has_method("_push") and ram:
			var push_dir = last_direction.normalized()
			collider._push(push_dir)

func _physics_process(_delta: float) -> void:
	_movement(_delta)
