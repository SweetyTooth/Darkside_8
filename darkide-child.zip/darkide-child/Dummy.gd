extends CharacterBody2D

const tile_size: Vector2 = Vector2(128, 128)
var sprite_node_pos_tween: Tween

func _ready() -> void:
	pass

# Moves the dummy one tile in the given direction
# Called by the player when dashing with ram enabled
func _push(dir: Vector2):
	if sprite_node_pos_tween and sprite_node_pos_tween.is_running():
		return  # Don't push if already moving
	
	global_position += dir * tile_size
	
	if sprite_node_pos_tween:
		sprite_node_pos_tween.kill()
	sprite_node_pos_tween = create_tween()
	sprite_node_pos_tween.set_process_mode(Tween.TWEEN_PROCESS_PHYSICS)
	sprite_node_pos_tween.tween_property(self, "position", position, 0.185).set_trans(Tween.TRANS_SINE)
